import { Component, input } from '@angular/core';
import { Character } from '../../interface/character-list-response';

@Component({
  imports: [],
  selector: 'app-character-item-componet',
  styleUrl: './character-item-componet.css',
  templateUrl: './character-item-componet.html',
})
export class CharacterItemComponet {
  character = input<Character>();
}
