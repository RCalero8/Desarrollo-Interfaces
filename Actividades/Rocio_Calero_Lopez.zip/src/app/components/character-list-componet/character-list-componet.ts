import { Component, inject, OnInit, signal } from '@angular/core';
import { CharacterItemComponet } from '../character-item-componet/character-item-componet';
import { CharacterService } from '../../service/character-service';
import { Character } from '../../interface/character-list-response';
@Component({
  imports: [CharacterItemComponet],
  selector: 'app-character-list-componet',
  styleUrl: './character-list-componet.css',
  templateUrl: './character-list-componet.html',
})
export class CharacterListComponet implements OnInit{
  characterService = inject(CharacterService)
  characterList = signal<Character[]>([]);

  ngOnInit(): void {
    this.characterService.getAllCharacter().subscribe(resp => {
      this.characterList.set(resp.results);
    });
  }
}
