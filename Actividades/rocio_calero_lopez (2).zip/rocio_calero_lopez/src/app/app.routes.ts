import { Routes } from '@angular/router';

export const routes: Routes = [
    { path: '', redirectTo: 'pokemon', pathMatch: 'full' },
    { path: 'pokemon', component: PokemonListComponent },
    { path: 'pokemon/:id', component: PokemonDetailComponent },
    { path: 'berries', component: BerryListComponent },
    { path: 'berries/:id', component: BerryDetailComponent },
    { path: 'items', component: ItemListComponent },
    { path: 'items/:id', component: ItemDetailComponent },
    { path: '**', redirectTo: 'pokemon' },
];
